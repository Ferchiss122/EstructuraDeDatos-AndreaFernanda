﻿// See https://aka.ms/new-console-template for more information
using Farenheit;
{

    Temperaturaa unTemperatura = new Temperaturaa();

    Console.WriteLine("Aplicacion para convertir grados Farenheit a Celcius:)");
    Console.WriteLine("Teclee la temperatura en grados Farenheit");
    unTemperatura.Farenheit = double.Parse(Console.ReadLine());

    Console.WriteLine("------------------------------------------------------------------------------------------------------------");
    Console.WriteLine("La temperatura en grados celusius es: " + unTemperatura.Convertir().ToString("N2") + "°C");

    Console.ReadKey();








}
