﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Farenheit
{
    internal class Temperaturaa
    {
        private double _dblFarenheit;

        public double Farenheit
        {
            set { _dblFarenheit = value; }
         
        }

        public double Convertir()
        { 
        return (((_dblFarenheit - 32)* 5 )/ 9);
        }



    }
}
