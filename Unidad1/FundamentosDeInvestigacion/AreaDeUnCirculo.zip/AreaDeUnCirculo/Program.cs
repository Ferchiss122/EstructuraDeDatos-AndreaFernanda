﻿// See https://aka.ms/new-console-template for more information
using AreaDeUnCirculo;

Circulo unCirculo = new Circulo();

Console.WriteLine("Aplicación para calcular el area de un circulo.");

Console.WriteLine("Ingrese el radio del circulo:)");
unCirculo.Radio = double.Parse(Console.ReadLine());

Console.WriteLine("------------------------------------------------------------------------------------------------------------");

Console.WriteLine("El area del circulo es: " + unCirculo.CalcularArea().ToString("N2") + "cm²");
Console.ReadKey();

