﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaLibro
{
    internal class Libro
    {
		private string _strTitulo;
		public string Titulo
		{
			get { return _strTitulo; }
			set { _strTitulo = value; }
		}

		private string _strAutor;
		public string Autor
		{
			get { return _strAutor; }
			set { _strAutor = value; }
		}

		public void MostrarDatos()
		{
			Console.WriteLine("Datos del libro: " +
				"\nTítulo: " + Titulo +
				"\nAutor: " + Autor +
				"\nGuardando libro...");
		}
	}
}
