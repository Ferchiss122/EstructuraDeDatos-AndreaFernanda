﻿// See https://aka.ms/new-console-template for more information
using PracticaLibro;

Libro unLibro = new Libro();

Console.WriteLine("Aplicación para guadar libros.");
Console.WriteLine("Ingrese el título del libro.");
unLibro.Titulo = Console.ReadLine();
Console.WriteLine("Ingrese el autor del libro");
unLibro.Autor = Console.ReadLine();

Console.Clear();
Console.WriteLine("------------------------------------------------------------------------");
unLibro.MostrarDatos();
Console.ReadKey();
