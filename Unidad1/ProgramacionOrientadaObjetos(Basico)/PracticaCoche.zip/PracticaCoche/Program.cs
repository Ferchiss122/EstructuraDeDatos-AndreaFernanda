﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaCoche
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Coche unCoche = new Coche();
            Console.WriteLine("Ingrese la marca del coche.");
            unCoche.Marca = (Console.ReadLine());
            Console.WriteLine("Ingrese el modelo del coche");
            unCoche.Modelo = (Console.ReadLine());
            Console.WriteLine("Ingrese la velocidad del coche (velocidad en km/h).");
            unCoche.Velocidad = double.Parse(Console.ReadLine());

            Console.Clear();
            Console.WriteLine("------------------------------------------------------------------------");
            Console.WriteLine("Datos del coche:" +
                "\nMarca: " + unCoche.Marca +
                "\nModelo: " + unCoche.Modelo);
            unCoche.Acelerar();
            unCoche.Frenar();

            Console.ReadKey();
        }
    }
}
