﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaCoche
{
    internal class Coche
    {
		private string _strMarca;
		public string Marca
		{
			get { return _strMarca; }
			set { _strMarca = value; }
		}

		private string _strModelo;
		public string Modelo
		{
			get { return _strModelo; }
			set { _strModelo = value; }
		}

		private double _dblVelocidad;

		public double Velocidad
		{
			get { return _dblVelocidad; }
			set { _dblVelocidad = value; }
		}

		public void Acelerar()
		{
			Console.WriteLine("El coche esta acelerando a una velocidad de " + Velocidad + " km/h");
		}

		public void Frenar()
		{
			Console.WriteLine("El coche esta frenando. . .");
		}



	}
}
