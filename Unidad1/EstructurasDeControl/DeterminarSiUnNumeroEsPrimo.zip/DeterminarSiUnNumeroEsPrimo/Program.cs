﻿// See https://aka.ms/new-console-template for more information
using System.Reflection.Metadata.Ecma335;

Console.WriteLine("Aplicación para determinar si un número es primo.");

Console.WriteLine("Ingrese un numero que sea positivo.");
int numero  = int.Parse(Console.ReadLine());

Console.WriteLine("------------------------------------------------------------------------------------------------------------");

bool esPrimo = true;

if (numero <= 1)
{
    esPrimo = false;
}
else
{
    for (int i = 2; i < numero; i++)
    {
        if (numero % i == 0)
        {
            esPrimo = false;
            break; 
        }
    }
}

if (esPrimo)
{
    Console.WriteLine(numero + " es un número primo.");
}
else
{
    Console.WriteLine(numero + " no es un número primo.");
}

Console.ReadKey();