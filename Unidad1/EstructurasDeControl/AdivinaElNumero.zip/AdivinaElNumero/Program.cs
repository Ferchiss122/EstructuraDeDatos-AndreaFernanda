﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Juego de " + "adivina el número" + ", ¡diviértete!");
Random random = new Random();
int num;
int numcorrecto;

    num = 0;
    numcorrecto = 0;
    numcorrecto = random.Next(1, 11);

while (num != numcorrecto)
{
    Console.WriteLine("Porfavor ingresa un número en un rango del 1 - 10 :).");
    num = int.Parse(Console.ReadLine());
    Console.WriteLine("Tu numero elegido es: " + num);
    Console.WriteLine("------------------------------------------------------------------------------------------------------------");

    if (num != numcorrecto)
        Console.WriteLine("¡Número equivocado!");
}

    Console.WriteLine("El numero correcto es: " + numcorrecto);
    Console.WriteLine("¡Felicidades, ganaste! :)"); 
    
    Console.ReadKey();


