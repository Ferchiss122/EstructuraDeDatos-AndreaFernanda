﻿// See https://aka.ms/new-console-template for more information
List<int> numeros = new List<int>();

Console.WriteLine("Ingrese la cantidad de números que ingresara:");
int cantidad;

while (!int.TryParse(Console.ReadLine(), out cantidad) || cantidad <= 0)
{
    Console.WriteLine("Por favor, ingresa un número entero mayor que 0.");
}


for (int i = 0; i < cantidad; i++)
{
    Console.Write($"Ingresa el número #{i + 1}: ");
    int numero;
    while (!int.TryParse(Console.ReadLine(), out numero))
    {
        Console.Write("Entrada no válida. Ingresa un número entero: ");
    }
    numeros.Add(numero);
}


double promedio = CalcularPromedio(numeros);
Console.WriteLine($"\nEl promedio de los números ingresados es: {promedio:F2}");
        

     
        static double CalcularPromedio(List<int> lista)
{
    if (lista == null || lista.Count == 0)
    {
        throw new ArgumentException("La lista no puede estar vacía.");
    }

    int suma = 0;
    foreach (int numero in lista)
    {
        suma += numero;
    }

    return (double)suma / lista.Count;
}


