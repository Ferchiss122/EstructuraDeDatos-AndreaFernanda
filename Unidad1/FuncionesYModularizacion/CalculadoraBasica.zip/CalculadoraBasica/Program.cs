﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Aplicación de calculadora básica.");

Console.WriteLine("Ingrese el primer número");
int num1 = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese el segundo número.");
int num2 = int.Parse(Console.ReadLine());

int opcion;
double resultado;
do
{
    Console.WriteLine("---------------------------------------------------------------------------------------");
    Console.WriteLine("Menú de calculadora.");

    Console.WriteLine("1. Suma.");
    Console.WriteLine("2. Resta.");
    Console.WriteLine("3. Multiplicación.");
    Console.WriteLine("4. División.");
    Console.WriteLine("0. Salir");
    Console.WriteLine("Eliga su opción:");
    opcion = int.Parse(Console.ReadLine());

    switch (opcion)
    {

        case 1:
            resultado = num1 + num2;
            Console.WriteLine("El resultado de la suma es: " + resultado);
            break;

        case 2:
            resultado = num1 - num2;
            Console.WriteLine("El resultado de la resta es: " + resultado);
            break;

        case 3:
            resultado = num1 * num2;
            Console.WriteLine("El resultado de la multiplicación es: " + resultado);
            break;
        case 4:
             resultado = num1 / num2;
            Console.WriteLine("El resultado de la división es: " + resultado);
            break;

    }

} while (opcion != 0);
Console.WriteLine("¡ADIOSSS! :D");
