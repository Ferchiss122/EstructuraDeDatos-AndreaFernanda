﻿// See https://aka.ms/new-console-template for more information
using PracticaBiblioteca;

int opcion;
Biblioteca unaBiblioteca = new Biblioteca();
Usuario usuario = new Usuario();
Libro libro = new Libro();
do
{
    Console.WriteLine("---------------------------------------------------------------------------------------");
    Console.WriteLine("Menú de biblioteca.");

    Console.WriteLine("1. Registrar a usuario.");
    Console.WriteLine("2. Registrar libro.");
    Console.WriteLine("3. Préstamo.");
    Console.WriteLine("4. Devolución.");
    Console.WriteLine("0. Salir");
    Console.WriteLine("Eliga su opción:");
    opcion = int.Parse(Console.ReadLine());

    switch (opcion)
    {

        case 1:
            Console.WriteLine("---------------------------------------------------------------------------------------");
            Console.WriteLine("Ingrese el nombre del usuario.");
            usuario.Nombre = Console.ReadLine();
            Console.WriteLine("Ingrese su ID");
            usuario.ID = Console.ReadLine();
            Console.WriteLine("¡Datos guardados!");
            break;
            
        case 2:
            Console.WriteLine("---------------------------------------------------------------------------------------");
            Console.WriteLine("Ingrese el título del libro.");
            libro.Titulo = Console.ReadLine();
            Console.WriteLine("Ingrese el autor del libro.");
            libro.Autor = Console.ReadLine();
            Console.WriteLine("Ingrese el ISBN.");
            libro.ISBN = Console.ReadLine();
            Console.WriteLine("¡Datos guardados!");
            break;
           

        case 3:
            Console.WriteLine("---------------------------------------------------------------------------------------");
            unaBiblioteca.Prestamo();
            break;
        case 4:
            Console.WriteLine("---------------------------------------------------------------------------------------");
            unaBiblioteca.Devolucion();
            break;
          

    }

} while (opcion != 0);
Console.WriteLine("¡Vuelva pronto!");
