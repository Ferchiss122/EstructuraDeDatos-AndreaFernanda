﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaBiblioteca
{
    internal class Biblioteca
    {
        public void Prestamo()
        {
            Console.WriteLine("El libro sera enviado, ¡disfrutelo!");
        }

        public void Devolucion()
        {
            Console.WriteLine("El libro sera devuelto, ¡gracias!:)");
        }
    }
}
