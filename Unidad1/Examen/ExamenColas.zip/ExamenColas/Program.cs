﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    { 
        Queue<string> colaimpresion = new Queue<string>();
        colaimpresion.Enqueue("doc1.pdf");
        colaimpresion.Enqueue("Tarea.docx");
        colaimpresion.Enqueue("Presentacion.pptx");
        Console.WriteLine("Cola inicial de impresión:");
        MostrarCola(colaimpresion);

        string atendido = colaimpresion.Dequeue();
        Console.WriteLine($"\nImprimiendo: {atendido}");

       
        string nuevodocumento = "informe.pdf";
        colaimpresion.Enqueue(nuevodocumento);
        Console.WriteLine($"\nNuevo documento agregado: {nuevodocumento}");

      
        Console.WriteLine("\nOrden final de impresión:");
        MostrarCola(colaimpresion);
    }

   
    static void MostrarCola(Queue<string> cola)
    {
        foreach (var documento in cola)
        {
            Console.WriteLine($"- {documento}");
        }
    }
}
