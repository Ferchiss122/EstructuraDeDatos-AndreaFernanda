﻿using System;
using System.Collections.Generic;


class Program
{
    static void Main()
    {
        List<string> nombres = new List<string>();
        string entrada;

        Console.WriteLine("Escribe el nombre del alumno. Escribe 'fin' para terminar.");

        while (true)
        {
            Console.Write("Nombre: ");
            entrada = Console.ReadLine();

            if (entrada.ToLower() == "fin")
            {
                break;
            }

            if (!string.IsNullOrWhiteSpace(entrada))
            {
                nombres.Add(entrada);
            }
        }

        Console.WriteLine($"\nSe ingresaron {nombres.Count} nombres.");
        foreach (string nombre in nombres)
        {
            Console.WriteLine($"-{nombre}");
        }
    }

}