﻿// See https://aka.ms/new-console-template for more information

using ExamDiag;

Rectangulo unRectangulo = new Rectangulo(10, 5);
Cuadrado unCuadrado = new Cuadrado(5);
int opcion;
do
{
    Console.WriteLine("---------------------------------------------------------------------------------------");
    Console.WriteLine("Menú .");

    Console.WriteLine("1. Calcular area y perimetro de un rectángulo.");
    Console.WriteLine("2.  Calcular area y perimetro de un cuadrado.");
    Console.WriteLine("0. Salir");
    Console.WriteLine("Eliga su opción:");
    opcion = int.Parse(Console.ReadLine());
    Console.Clear();

    switch (opcion)
    {

        case 1:
            Console.WriteLine("Ingrese el valor del ancho: ");
            unRectangulo.Ancho = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el valor del alto: ");
            unRectangulo.Alto = int.Parse(Console.ReadLine());
            unRectangulo.MostrarDatos();
            break;
            Console.Clear();



        case 2:
            Console.WriteLine("Ingrese el valor del lado: ");
            unCuadrado.Ancho = int.Parse(Console.ReadLine());
            unCuadrado.MostrarDatos();
            break;
            Console.Clear();

      

    }

} while (opcion != 0);
Console.WriteLine("¡ADIOSSS! :D");

