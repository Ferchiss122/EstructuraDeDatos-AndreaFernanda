﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamDiag
{
    internal class Rectangulo
    {
		private int _dblAlto;
		public int Alto
		{
			get { return _dblAlto; }
			set { _dblAlto = value; }
		}

		private int _dblAncho;
		public int Ancho
		{
			get { return _dblAncho; }
			set { _dblAncho = value; }
		}

		public Rectangulo(int ancho, int alto)
		{
			_dblAncho = ancho;
			_dblAlto= alto;
		}

		public int CalcularArea()
		{
			int resu;
			resu = Alto * Ancho;
			return resu;
		}

		public double CalcularPerimetro()
		{
			double resul;
			resul = (Alto * 2) + (Ancho * 2);
			return resul;
		}

		public virtual void MostrarDatos()
		{
			Console.WriteLine("Datos del rectangulo: " +
				"\nAncho: " + Ancho +
				"\nAlto: " + Alto +
				"\nArea: " + CalcularArea() +
				"\nPerimetro: " + CalcularPerimetro());
		}




	}
}
