﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamDiag
{
    internal class Cuadrado : Rectangulo
    {
        public Cuadrado(int lado) : base(lado, lado)
        {
        }

        public override void MostrarDatos()
        {
            Console.WriteLine("Datos del cuadrado: " +
                "\nLado: " + Ancho +
                "\nArea: " + CalcularArea() +
                "\nPerimetro: " + CalcularPerimetro());
        }
    }
}
